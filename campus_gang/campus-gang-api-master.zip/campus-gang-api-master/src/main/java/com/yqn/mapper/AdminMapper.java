package com.yqn.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.yqn.pojo.Admin;

/**
 * @author sxc
 */
public interface AdminMapper extends BaseMapper<Admin> {
}
