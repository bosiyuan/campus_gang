package com.yqn.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.yqn.pojo.Task;

/**
 * @author sxc
 */
public interface TaskService extends IService<Task> {
}
