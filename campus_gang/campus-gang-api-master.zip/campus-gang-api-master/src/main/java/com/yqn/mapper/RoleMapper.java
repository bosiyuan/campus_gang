package com.yqn.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.yqn.pojo.Role;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author sxc
 */
@Mapper
public interface RoleMapper extends BaseMapper<Role> {
}
