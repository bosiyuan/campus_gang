package com.yqn.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.yqn.pojo.Dept;

/**
 * @author sxc
 */
public interface DeptService extends IService<Dept> {
}
