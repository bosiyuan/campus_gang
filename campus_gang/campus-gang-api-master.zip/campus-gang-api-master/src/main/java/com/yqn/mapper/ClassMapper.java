package com.yqn.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.yqn.pojo.Class;

/**
 * @author sxc
 */
public interface ClassMapper extends BaseMapper<Class> {
}
