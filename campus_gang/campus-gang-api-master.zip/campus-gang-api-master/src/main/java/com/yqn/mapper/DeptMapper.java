package com.yqn.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.yqn.pojo.Dept;

/**
 * @author sxc
 */
public interface DeptMapper extends BaseMapper<Dept> {

}
