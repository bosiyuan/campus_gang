package com.yqn.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.yqn.pojo.School;

/**
 * @author sxc
 */
public interface SchoolMapper extends BaseMapper<School> {
}
