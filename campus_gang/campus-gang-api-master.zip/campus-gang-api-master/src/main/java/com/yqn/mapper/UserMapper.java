package com.yqn.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.yqn.pojo.User;

/**
 * @author sxc
 */
public interface UserMapper extends BaseMapper<User> {
}
