package com.yqn.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.yqn.pojo.School;

/**
 * @author sxc
 */
public interface SchoolService extends IService<School> {
}
