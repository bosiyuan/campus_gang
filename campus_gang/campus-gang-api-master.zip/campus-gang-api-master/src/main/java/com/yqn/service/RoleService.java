package com.yqn.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.yqn.pojo.Role;

public interface RoleService extends IService<Role> {
}
