package com.yqn.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.yqn.pojo.Class;

/**
 * @author sxc
 */
public interface ClassService extends IService<Class> {
}
