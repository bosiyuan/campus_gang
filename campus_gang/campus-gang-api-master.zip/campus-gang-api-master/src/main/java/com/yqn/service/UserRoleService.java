package com.yqn.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.yqn.pojo.UserRole;


public interface UserRoleService extends IService<UserRole> {
}
