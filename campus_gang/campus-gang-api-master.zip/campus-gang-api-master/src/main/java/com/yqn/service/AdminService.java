package com.yqn.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.yqn.pojo.Admin;

/**
 * @author sxc
 */
public interface AdminService extends IService<Admin> {
}
