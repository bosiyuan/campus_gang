package com.yqn.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.yqn.pojo.User;

/**
 * @author sxc
 */
public interface UserService extends IService<User> {
}
